In order to check that everything works correctly please download the project files from the course website, open a terminal and go into your project folder. Then run CMake and if everything is set up correctly you should not receive any error. Run make to generate an executable from the project files.

What we did:

```bash
brew install sdl12-compat
brew install cmake
cmake .
make
./FirstLab
```
